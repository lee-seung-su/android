package com.example.a1313

class kakao_item(var image:Int, var name :String, var content : String, var draw_flag : Boolean = false)